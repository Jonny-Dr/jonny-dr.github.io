# VPN连接

# Clash Verge

链接：https://github.com/clash-verge-rev/clash-verge-rev/releases

windows 11下载这个64位版本，我给你放压缩包里

![image](assets/image-20251222171641-cijctpv.png)

# 什么是机场

“**VPN机场**”是中文网络环境里的一种**俗称**，并不是正式的技术名词，主要指的是**提供科学上网/翻墙服务的平台代理或服务商**。

这个说法来源于早期翻墙圈的比喻：

- **机场**：提供很多“航线”
- **航线**：不同国家/地区的服务器节点（美国、日本、新加坡等）
- **乘客**：用户
- **登机**：连接节点上网

也就是说，​**机场**  **=**  **提供大量代理节点的服务平台**。

我一般用两个平台，一个是魔戒：按量付费，永久有效，GPT稳定，订阅链接可以随时更新。一个是xfltd：按月付费，速度快但是GPT不稳定，订阅链接有效期是15分钟，不能开自动更新。

注意：不要一次性买太多，平台容易跑路！！！！！一点一点买或者一个月一个月买！！！！！

注意：按量订阅没用完之前不要买，会导致剩余流量被覆盖，按月的也是，没到期就别续费或者升级套餐。

其他：这俩链接虽然在国内可以访问，但是可能会被ban掉，要是访问不了你滴滴我，我看看是否有其他链接。

魔戒：https://mojie.app/login

xfltd：https://my.xfltd.org/#/landing

# clash verge使用

在机场复制订阅地址

![image](assets/image-20251222172116-10omua6.png)

输入到订阅链接，然后导入，然后点亮

![image](assets/image-20251222172135-4nd4a5g.png)

进入代理页面，点一下这个图表看看哪些代理服务器可以用，选择想用的就行

注意，流量是存在一个倍率关系，比如xfltd的LEPL专线代理使用流量要×4

规则代理的意思是会有一个自动的白名单，国内的站点不走代理服务器，这样安全而且节省流量，全局的意思是全部流量都走代理服务器（注意，如果所有流量都走代理，可能存在数据泄露风险），直连的意思是所有的流量都直接访问不使用代理。

![image](assets/image-20251222172303-7ny9gsy.png)

在任务栏可以右键这个图表选择开启系统代理，或者在设置页面开启

![image](assets/image-20251222172616-8r5eqsc.png)

![image](assets/image-20251222172437-0atxskv.png)

# 最佳方案

不要使用全局代理，直接选好节点之后启用浏览器代理，比如我使用Edge和谷歌浏览器两个，我只让谷歌浏览器进行VPN连接。

在谷歌浏览器中安装ZeroOmega3，注意别选错了

![image](assets/image-20251222172814-yt74vtv.png)

![image](assets/image-20251222172738-jd0i9ad.png)

clash verge会自动启用一个代理地址

![image](assets/image-20251222172842-60e8gn3.png)

打开谷歌浏览器的ZeroOmega配置页面

![image](assets/image-20251222172915-q660jgo.png)

点击proxy设置好代理服务器地址，和clash verge同步

![image](assets/image-20251222172948-3dnhrxs.png)

接下来就可以控制谷歌浏览器是否连接VPN，当状态为proxy时所有的流量都走clash verge，如果是系统代理，clash verge开启系统代理的情况下可以用，直接连接就是不连接clash verge

![image](assets/image-20251222173027-p7yc4nl.png)

最佳方案就是：只让谷歌浏览器链接clash verge，clash verge无需开启全局代理，只需要开启规则模式即可。

Edge同理。

# 其他：

手机也有对应的软件比如clash for Android，或者clash meta等等，可以搜索github进行下载安装，使用方式和clash verge大同小异。

不要在外网发任何的评论，不要在手机上下载敏感软件！！！！！！

‍
